package com.example.order.model;

import jakarta.persistence.*;



@Entity
@Table(name = "orders")
public class Orders {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idOrders;

    private String Model;
    private String Size;
    private String DeliveryAddress;
    private Double Amount;

    @ManyToOne
    @JoinColumn(name = "client_id")
    private Clients client;

    @ManyToOne
    @JoinColumn(name = "manager_id")
    private Managers manager;

//    public Orders(Long idOrders, Clients client, Managers Manager, String Model, String Size, String DeliveryAddress, Double Amount) {
//        this.idOrders = idOrders;
//        this.client = client;
//        this.manager = Manager;
//        this.Model = Model;
//        this.Size = Size;
//        this.DeliveryAddress = DeliveryAddress;
//        this.Amount = Amount;
//    }

    public Orders(Clients client, Managers manager, String Model, String Size, String DeliveryAddress, Double Amount) {
        this.client = client;
        this.manager = manager;
        this.Model = Model;
        this.Size = Size;
        this.DeliveryAddress = DeliveryAddress;
        this.Amount = Amount;
    }
    public Orders() {

    }

    public Long getId() {return idOrders;}
    public void setId(Long idOrders) {this.idOrders = idOrders;}
    public Clients getClient() {return client;}
    public void setClient(Clients client) {this.client = client;}
    public Managers getManager() {return manager;}
    public void setManager(Managers manager) {this.manager = manager;}
    public String getModel() {return Model;}
    public void setModel(String Model) {this.Model = Model;}
    public String getSize() {return Size;}
    public void setSize(String Size) {this.Size = Size;}
    public String getDeliveryAddress() {return DeliveryAddress;}
    public void setDeliveryAddress(String DeliveryAddress) {this.DeliveryAddress = DeliveryAddress;}
    public Double getAmount() {return Amount;}
    public void setAmount(Double amount) {this.Amount = amount;}
    @Override
    public String toString() {
        return "Order{" +
                "id=" + idOrders +
                ", Client='" + client + '\'' +
                ", Manager='" + manager + '\'' +
                ", Model='" + Model + '\'' +
                ", Size=" + Size + '\'' +
                ", DeliveryAddress=" + DeliveryAddress +
                ", orderAmount=" + Amount +
                '}';
    }
}
package com.example.order.service;

import java.util.List;
import java.util.Optional;

import com.example.order.model.Clients;
import com.example.order.repository.ClientRepository;



public class ClientService {
    private final ClientRepository clientRepository;

    public ClientService(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }

    public List<Clients> getAllClients() {
        return clientRepository.findAll();
    }

    public Optional<Clients> getClientById(Long id) {
        return clientRepository.findById(id);
    }

    public Clients createclient(Clients client) {
        return clientRepository.save(client);
    }
}

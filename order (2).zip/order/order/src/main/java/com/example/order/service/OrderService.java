package com.example.order.service;


import com.example.order.model.Orders;
import com.example.order.repository.OrderRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    private final OrderRepository orderRepository;

    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public List<Orders> getAllOrders() {
        return orderRepository.findAll();
    }

    public Optional<Orders> getOrderById(Long id) {
        return orderRepository.findById(id);
    }

    public Orders createOrder(Orders order) {
        return orderRepository.save(order);
    }

//    public Orders updateOrder(Long id, Orders orderDetails) {
//        Orders order = orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
//        order.setClient(orderDetails.getClient());
//        order.setManager(orderDetails.getManager());
//        order.setModel(orderDetails.getModel());
//        order.setSize(orderDetails.getSize());
//        order.setDeliveryAddress(orderDetails.getDeliveryAddress());
//        order.setAmount(orderDetails.getAmount());
//        return orderRepository.save(order);
//    }

//    public void deleteOrder(Long id) {
//        orderRepository.deleteById(id);
//    }



}

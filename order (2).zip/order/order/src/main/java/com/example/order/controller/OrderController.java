// src/main/java/com/example/ordersystem/OrderController.java
package com.example.order.controller;

import com.example.order.model.Orders;
import com.example.order.repository.ClientRepository;
import com.example.order.repository.ManagerRepository;
import com.example.order.repository.OrderRepository;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.order.model.Clients;
import com.example.order.model.Managers;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final ClientRepository clientRepository;
    private final ManagerRepository managerRepository;

    private final OrderRepository orderRepository;
    public OrderController(ClientRepository clientRepository, ManagerRepository managerRepository, OrderRepository orderRepository) {
        this.clientRepository = clientRepository;
        this.managerRepository = managerRepository;
        this.orderRepository = orderRepository;
    }




    @GetMapping("/all")
    public List<Orders> getAllOrders() {
        return orderRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Orders> getOrderById(@PathVariable Long id) {
        return orderRepository.findById(id)
                .map(order -> ResponseEntity.ok().body(order))
                .orElse(ResponseEntity.notFound().build());
    }
    @PostMapping
    public ResponseEntity<Orders> createOrder(@RequestBody Orders order) {
        Optional<Clients> clientOptional = clientRepository.findById(order.getClient().getId());

        if (clientOptional.isEmpty()) {
            return ResponseEntity.badRequest().body(null); // или выбросьте исключение
        }

        // Найти менеджера по его ID
        Optional<Managers> managerOptional = managerRepository.findById(order.getManager().getId());
        if (managerOptional.isEmpty()) {
            return ResponseEntity.badRequest().body(null); // или выбросьте исключение
        }
        Orders newOrder = new Orders(
                clientOptional.get(),
                managerOptional.get(),
                order.getModel(),
                order.getSize(),
                order.getDeliveryAddress(),
                order.getAmount()
        );

        Orders savedOrder = orderRepository.save(newOrder);
        return ResponseEntity.ok(savedOrder);
    }
    @PutMapping("/{id}")
    public ResponseEntity<Orders> updateOrder(@PathVariable Long id, @RequestBody Orders orderDetails) {
        return orderRepository.findById(id)
                .map(order -> {
                    order.setModel(orderDetails.getModel());
                    order.setSize(orderDetails.getSize());
                    order.setDeliveryAddress(orderDetails.getDeliveryAddress());
                    order.setAmount(orderDetails.getAmount());
                    Orders updatedOrder = orderRepository.save(order);
                    return ResponseEntity.ok().body(updatedOrder);
                }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrder(@PathVariable Long id) {
        return orderRepository.findById(id)
                .map(order -> {
                    orderRepository.delete(order);
                    return ResponseEntity.ok().<Void>build();
                }).orElse(ResponseEntity.notFound().build());
    }
}

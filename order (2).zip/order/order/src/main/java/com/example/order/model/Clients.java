package com.example.order.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Clients {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idClient;
    private String FIO;
    private String Email;
    private String Number;
    private String Address;

    public Clients(Long idClient, String FIO, String Email, String Number, String Address) {
        this.idClient = idClient;
        this.FIO = FIO;
        this.Email = Email;
        this.Number = Number;
        this.Address = Address;
    }
    public Clients(String FIO, String Email, String Number, String Address){
        this.FIO = FIO;
        this.Email = Email;
        this.Number = Number;
        this.Address = Address;
    }
    public Clients() {

    }
    public Long getId() {return idClient;}
    public void setId(Long idClient) {this.idClient = idClient;}
    public String getFIO() {return FIO;}
    public void setFIO(String FIO) {this.FIO = FIO;}
    public String getNumber() {return Number;}
    public void setNumber(String Number) {this.Number = Number;}
    public String getAddress() {return Address;}
    public void setAddress(String Address) {this.Address = Address;}
    public String getEmail() {return Email;}
    public void setEmail(String Email) {this.Email = Email;}
    @Override
    public String toString() {
        return "Client{" +
                "id=" + idClient +
                ", FIo='" + FIO + '\'' +
                ", Number='" + Number + '\'' +
                ", Email='" + Email + '\'' +
                ", Address=" + Address + '\'' +
                '}';
    }
}
